from flask import Flask, render_template, request, jsonify
import pymysql

app = Flask(__name__)

db_connection = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'site1',
    'cursorclass': pymysql.cursors.DictCursor
}

def get_db_connection():
    return pymysql.connect(**db_connection)

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    email = data.get('email')

    try:
        # Kết nối tới cơ sở dữ liệu
        connection = get_db_connection()
        cursor = connection.cursor()

        # Kiểm tra nếu username đã tồn tại
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()

        if user:
            return jsonify({"status": "error", "message": "Username đã tồn tại"}), 400

        # Thêm người dùng mới vào cơ sở dữ liệu
        cursor.execute("INSERT INTO users (username, password, email) VALUES (%s, %s, %s)", (username, password, email))
        connection.commit()

        return jsonify({"status": "success", "message": "Đăng ký thành công!"})
    finally:
        cursor.close()
        connection.close()

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    try:
        # Kết nối tới cơ sở dữ liệu
        connection = get_db_connection()
        cursor = connection.cursor()

        # Kiểm tra thông tin đăng nhập
        cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
        user = cursor.fetchone()

        if user:
            return jsonify({"status": "success", "message": "Đăng nhập thành công!"})
        else:
            return jsonify({"status": "error", "message": "Thông tin đăng nhập không chính xác"}), 400
    finally:
        cursor.close()
        connection.close()


if __name__ == '__main__':
    app.run(debug=True)
